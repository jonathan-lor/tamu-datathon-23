import requests
import json
import attorney.variables as variables


def get_challenges():
    payload = ""
    headers = {"User-Agent": "insomnia/2023.5.8"}

    response = requests.request("GET", variables.LEADERBOARD_URL, headers=headers)
    challenges = json.loads(response.content)

    return [(idx, challenge_name) for idx, challenge_name in enumerate(challenges)]


def request_judge(challenge_id: int, email: str, url: str, port: int) -> str:
    base_url = f"http://{url}:{port}"

    payload = {
        "challenge_id": challenge_id,
        "base_url": base_url,
        "email": email
    }
    headers = {"Content-Type": "application/json"}

    try:
        response = requests.request("POST", variables.RICHTER_URL, json=payload, headers=headers)
        if response.status_code == 500:
            print(f"Response: {response.content}")
            return "ERROR! PLEASE TEST LOCALLY AND MAKE SURE YOU SELECTED THE RIGHT INFORMATION. IF IT WORKS LOCALLY, " \
                   "TALK TO TD ORGANIZER"
        return str(json.loads(response.content)["score"])
    except Exception as e:
        print(f"[!] Exception: {e}")
        return "ERROR! PLEASE TEST LOCALLY AND MAKE SURE YOU SELECTED THE RIGHT INFORMATION. IF IT WORKS LOCALLY, " \
               "TALK TO TD ORGANIZER"
